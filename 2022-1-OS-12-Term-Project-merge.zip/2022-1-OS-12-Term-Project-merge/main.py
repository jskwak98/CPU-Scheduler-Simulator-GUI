"""
main.py

3 stages

1. input from console
    a. add process
    b. specify scheduling algorithm
    -> use argparser

2. use appropriate scheduler and get WT, RT, TT for each process and average values

3. Use ChartDrawer from draw.py, using Schedule object as an input
"""